#! /usr/bin/env python3
import setuptools

setuptools.setup(
    name='bash',
    version='0.0.1',
    author='zrcai',
    author_email='1571301668@qq.com',
    description='A module designed for running bash commands',
    python_requires='>3.6'
)
